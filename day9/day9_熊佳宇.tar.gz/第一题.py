#!/usr/bin/python
# author Yu
# 2023年06月10日
with open("file.txt", 'w+',encoding="utf-8") as file:
    file.write("人生苦短 我用Python")

